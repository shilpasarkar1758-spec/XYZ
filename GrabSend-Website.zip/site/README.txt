Grab & Send website
===================
index.html            Landing page
app.html              The working web app (needs HTTPS for the camera)
downloads/GrabSend.apk  Put your built Android APK here (see the Android project's GitHub Actions build)

Host it free with GitHub Pages:
1. Create a GitHub repository and upload everything in this folder.
2. Settings > Pages > Source: "Deploy from a branch", Branch: main, folder: / (root). Save.
3. After a minute your site is live at https://<your-name>.github.io/<repository>/
   Open that link on both phones in Chrome.
